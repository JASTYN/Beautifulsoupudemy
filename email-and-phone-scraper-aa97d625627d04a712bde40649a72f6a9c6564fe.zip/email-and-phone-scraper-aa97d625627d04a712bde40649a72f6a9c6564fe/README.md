Python email address and phone number scraper by Cameron Cobb on October 17th, 2018.

Requirements:
Python 3.6
bs4
urllib
requests
openpyxl
datetime

If you have questions or want to contact me, visit my website https://www.cameroncobbconsulting.com